package com.alegria.alegria;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AlegriaApplication {

	public static void main(String[] args) {
		SpringApplication.run(AlegriaApplication.class, args);
	}

}
