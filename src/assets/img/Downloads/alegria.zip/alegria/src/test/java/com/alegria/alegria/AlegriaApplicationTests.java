package com.alegria.alegria;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AlegriaApplicationTests {

	@Test
	void contextLoads() {
	}

}
