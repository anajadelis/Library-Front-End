import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

from src.data_analysis.bootstrap import Bootstrap
from src.data_analysis.confidence_interval import ConfidenceInterval
from src.data_analysis.data_analysis import DataAnalysis


class PrintHelper:
    def __init__(self, filePath) -> None:
        self.data = pd.read_csv(filePath).astype(dtype=np.float64)

    def print_variable_ci(self, alpha, estimator, estimator_name, var_name, var_data=None):
        if var_data is None:
            var_data = self.data[var_name].to_numpy()

        # Real estimator value
        real_estimator_value = estimator(var_data)
        print("Real {}: {}".format(estimator_name, real_estimator_value))

        # Perform Bootstrap
        bootstrap = Bootstrap([var_data])
        bootstrap.calculate_bootstrap(estimator=estimator)

        # Confidence Interval
        ci_estimated = ConfidenceInterval(
            bootstrap.estimator_samples_result, alpha=alpha
        )

        lower_estimated = ci_estimated.calculate_lower_bound()
        upper = ci_estimated.calculate_upper_bound()

        print("Confidence Interval (alpha = {}) - "
              "Lower: {}, Upper: {}".format(alpha, lower_estimated, upper)
              )

    def print_correlation(self, alpha, estimator, var1_name, var2_name, var1_data=None, var2_data=None):
        var1_data = self.data[var1_name].to_numpy() if var1_data is None else var1_data
        var1_data.shape = (len(var1_data), 1)

        var2_data = self.data[var2_name].to_numpy() if var2_data is None else var2_data
        var2_data.shape = (len(var2_data), 1)

        # Real correlation
        real_correlation = estimator(
            list(np.hstack((var1_data, var2_data)))
        )
        print("Real correlation between '{}' and '{}': {}".format(
            var1_name, var2_name, real_correlation
        ))

        # Perform Bootstrap
        bootstrap = Bootstrap([var1_data, var2_data])
        bootstrap.calculate_bootstrap(estimator=estimator)

        # Confidence Interval
        ci_estimated = ConfidenceInterval(
            bootstrap.estimator_samples_result, alpha=alpha
        )

        lower_estimated = ci_estimated.calculate_lower_bound()
        upper = ci_estimated.calculate_upper_bound()

        print("Confidence Interval (alpha = {}) - "
              "Lower: {}, Upper: {}".format(alpha, lower_estimated, upper)
              )

    def print_ecdf(self, var_name):
        sorted_data = np.sort(self.data[var_name].to_numpy(), axis=0)
        ecdf_var = DataAnalysis.ecdf(sorted_data)

        plt.plot(sorted_data, ecdf_var)
        plt.xlabel(var_name)
        plt.ylabel('Cumulative')
        plt.title("ECDF: " + var_name)
        plt.show()

    def print_var_comparison(
            self,
            alpha,
            estimator,
            estimator_name,
            var1_name,
            is_correlation=False,
            var2_name=None
    ):

        unique_qualities = np.unique(self.data['quality'])

        qualities = {}
        for quality in unique_qualities:
            qualities[quality] = {'data': []}

        for index, row in self.data.iterrows():
            row_data = qualities[row['quality']]['data']

            var_data = [row[var1_name]]

            if var2_name is not None:
                var_data.append(row[var2_name])

            row_data.append(var_data)

        for data_class in qualities.keys():
            print(f"\n\nVariable '{var1_name}' info for class {data_class}")

            var_data = np.array(qualities[data_class]['data'])
            if not is_correlation:
                self.print_variable_ci(
                    var1_name,
                    alpha,
                    estimator,
                    estimator_name,
                    var_data[:, 0]
                )
            else:
                self.print_correlation(
                    alpha,
                    estimator,
                    var1_name,
                    var2_name,
                    var1_data=var_data[:, 0],
                    var2_data=var_data[:, 1]
                )
