from typing import List, Union

import numpy as np

from scipy.stats import norm


class ConfidenceInterval:
    def __init__(self, data: List[Union[int, float]], alpha):
        self.data = np.array(data)
        self.alpha = alpha

    def calculate_lower_bound(self):
        return norm.ppf(
            self.alpha / 2,
            loc=np.mean(self.data),
            scale=np.std(self.data)
        )

    def calculate_upper_bound(self):
        return norm.ppf(
            1 - (self.alpha / 2),
            loc=np.mean(self.data),
            scale=np.std(self.data)
        )
