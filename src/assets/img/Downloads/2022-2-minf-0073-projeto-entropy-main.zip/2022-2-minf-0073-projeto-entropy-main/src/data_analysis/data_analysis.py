import numpy as np

class DataAnalysis:

    @staticmethod
    def ecdf_value(x, sorted_data):
        counter = 0

        for data_point in sorted_data:
            if data_point <= x:
                counter += 1
            else:
                break

        return counter / len(sorted_data)

    @staticmethod
    def ecdf(sorted_data):
        return [DataAnalysis.ecdf_value(x, sorted_data) for x in sorted_data]