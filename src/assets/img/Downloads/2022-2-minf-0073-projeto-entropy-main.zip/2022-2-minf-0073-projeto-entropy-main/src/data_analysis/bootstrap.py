from typing import Callable, List, Union

import numpy as np


class Bootstrap:
    def __init__(self, data: List[List[Union[int, float]]]):
        self.data = None

        # Stack variables data side by side
        for random_var in data:
            random_var.shape = (len(random_var), 1)

            if self.data is None:
                self.data = random_var
            else:
                self.data = np.hstack((
                    self.data, random_var))

        self.bootstrap_sample_result = []
        self.estimator_samples_result = []

    def calculate_bootstrap(self, bootstraps=9999,
                            estimator: Callable = np.mean):

        self.bootstrap_sample_result = []
        self.estimator_samples_result = []

        data_length = len(self.data)

        print("(Bootstrap) progress bar: ", end="")
        for i in range(bootstraps):
            sample_result = self.data[np.random.choice(
                    data_length,
                    data_length,
                    replace=True
             )]

            self.bootstrap_sample_result.append(sample_result)
            self.estimator_samples_result.append(estimator(sample_result))

            # Print progress bar
            if (i+1) % int((0.05 * bootstraps)) == 0:
                print("=", end="")

        print("")
