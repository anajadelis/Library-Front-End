from math import sqrt
from typing import List

import numpy as np

from src.data_analysis.print_helper import PrintHelper


# Pearson’s product-moment correlation
# Reference https://rstudio-pubs-static.s3.amazonaws.com/197848_4619f985c83c438d849e737864841990.html
def pearson_correlation(sample_result: List[np.ndarray]):
    sample_result = np.array(sample_result)

    X = sample_result[:, 0]
    Y = sample_result[:, 1]
    n = X.shape[0]

    sum_x = sum(X)
    sum_y = sum(Y)

    return (n * sum(X * Y) - sum_x * sum_y) / \
           sqrt((n * sum(X ** 2) - (sum_x ** 2)) *
                (n * sum(Y ** 2) - (sum_y ** 2)))


if __name__ == "__main__":
    print_helper = PrintHelper("../data/winequality-white.csv")

    alpha = 0.05

    var1_name = 'density'

    print("-------------------------------------------------------------------")
    print("----------------------------Part 1---------------------------------")
    print("-------------------------------------------------------------------")

    # print(f"\n\nConfidence Interval for '{var1_name}' mean\n")
    #
    # print_helper.print_variable_ci(
    #     alpha, estimator=np.mean, estimator_name="mean", var1_name
    # )
    #
    # print(f"\n\nConfidence Interval for '{var1_name}' median\n")
    #
    # print_helper.print_variable_ci(
    #     alpha, estimator=np.median, estimator_name="median", var1_name
    # )
    #
    var2_name = 'alcohol'
    #
    # print(f"\n\nConfidence Interval of variables' correlation between "
    #       f"{var1_name} and {var2_name}\n")
    #
    # print_helper.print_correlation(
    #     alpha, estimator=pearson_correlation, var1_name, var2_name
    #
    #
    # print_helper.print_ecdf(var1_name)
    #
    # print_helper.print_ecdf(var2_name)

    print("\n\n")
    print("-------------------------------------------------------------------")
    print("----------------------------Part 2---------------------------------")
    print("-------------------------------------------------------------------")

    print_helper.print_var_comparison(
        alpha=alpha,
        estimator=pearson_correlation,
        estimator_name="mean",
        is_correlation=True,
        var1_name=var1_name, var2_name=var2_name
    )
