# Ativiadade Ciência da Computação
<img src="assets/images/Unicap_Icam_Tech-01.png" alt="drawing" width="200"/>

## Identificação
**Professor**: Nome do Professor

**Disciplina**: Nome da Disciplina

**Atividade**: Atividade XX - Título da Atividade

## Instruções 
> 1. Sua implementação deve estar dentro da pasta **src** 
> 2. Não modifique nenhum código dentro da pasta **test**
> 3. A submissão **não deve ser feita após o prazo** (nem 1 minuto a mais)

## Descrição da Atividade
### Questão 01
Altere o método `message_not_implmented` na classe `Hello` para, em vez de lançar uma exceção, retornar a menssagem `Hello World`. 
a
A classe `Hello` possui os dois métodos a seguir: 
1. Método `message_implemented` que está corretamente implementado e retorna a mensagem `Hello World`.     

2. Método `message_not_implemented` que não está corretamente implementado e lança uma exceção `NotImplementedError`. 

